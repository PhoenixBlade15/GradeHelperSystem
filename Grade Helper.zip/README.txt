	Grade Helper
This system is to help the user keep track of grades, 
courses, gpa, and how close you are to completing a concentration.

Made with Java Version 8 Update 231 (build 1.8.0_231-b11), this
or version is garunteed to work.

Steps to run:
	1) Place the "GradeHelperSystem.jar" in a place you want
		- This system creates a folder in the directory 
		  it's in.
	2) Double click the file.

Problem Solving: 
	If for some reason the program won't open first check
	that you have the correct version of java. If still
	doesn't work open the .jar as administrator.

Important Info:
	You can add and delete courses/grades as much as you 
	want, keeping the name the same will modify the grade
	currently in the system.
	When finished you can delete the folder if you are done
	with the program entirely, else you can leave it and 
	use this program often. 